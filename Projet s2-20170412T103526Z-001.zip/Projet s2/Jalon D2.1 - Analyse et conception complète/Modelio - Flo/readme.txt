*** IMPORTER LE PROJET ***

Sur la page de démarrage de Modelio cliquez sur "File"
puis "Switch worspace..."

Ensuite cliquez sur le dossier "workspace" puis sur ouvrir.
Cela devrait faire changer le workspace.
